﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ListyIterator
{
    public class ListyIterator<T>
    {
        List<T> internalList;
        int index = 0;

        public ListyIterator(params T[] parameters)
        {
            index = 0;
            internalList = new List<T>(parameters);
        }

        public bool Move()
        {
            if (index + 1 < internalList.Count)
            {
                index++;
                return true;
            }
            else
            {
                return false;
            }
        }

        public void Print()
        {
            if (internalList.Count == 0)
            {
                Console.WriteLine("Invalid Operation!");
            }
            else
            {
                Console.WriteLine(internalList[index]);
            }
        }

        public bool HasNext()
        {
            return (index + 1 < internalList.Count);
        }
    }
}
