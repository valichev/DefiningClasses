﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ListyIterator
{
    class Program
    {
        static void Main(string[] args)
        {
            ListyIterator<string> listyIterator = new ListyIterator<string>(Console.ReadLine().Split().Skip(1).ToArray());
            List<int> a = new List<int>();

            string input = Console.ReadLine();
            while (input != "END")
            {
                switch (input)
                {
                    case "Move":
                        Console.WriteLine(listyIterator.Move());
                        break;
                    case "Print":
                        listyIterator.Print();
                        break;
                    case "HasNext":
                        Console.WriteLine(listyIterator.HasNext());
                        break;
                    default:
                        break;
                }
                input = Console.ReadLine();
            }
        }
    }
}
